function searchingStrings(str, searchValue, startIndex = 0) {
    // First occurrence from startIndex
    let firstOccurrence = str.indexOf(searchValue, startIndex);
    // Last occurrence in the entire string (ignoring startIndex)
    let lastOccurrence = str.lastIndexOf(searchValue);

    return {
        firstOccurrence,
        lastOccurrence
    };
}

function handleSearchingStrings() {
    const str = document.getElementById("stringInput").value;
    const searchValue = document.getElementById("substringInput").value;
    const startIndex = parseInt(document.getElementById("startIndexInput").value) || 0;
    
    const results = searchingStrings(str, searchValue, startIndex);
    
    document.getElementById("searchResults").textContent = `
        First Occurrence: ${results.firstOccurrence}, 
        Last Occurrence: ${results.lastOccurrence}
    `;
}

// Alert on color selection
document.querySelectorAll('input[name="color"]').forEach(radio => {
    radio.addEventListener('change', function() {
        alert(`You selected ${this.value} color.`);
    });
});

// Function to change design and update text and image
function setDesign(designNumber) {
    document.getElementById("designText").value = `This is Design ${designNumber}`;
    document.getElementById("sofaImage").src = `image/design${designNumber}.jpg`;  // Update to match your image filenames
}

function findLongestWord(words) {
    let longestWord = "";
    for (let word of words) {
        if (word.length > longestWord.length) {
            longestWord = word;
        }
    }
    return longestWord;
}

function handleFindLongestWord() {
    const input = document.getElementById("wordsInput").value;
    const words = input.split(',').map(word => word.trim());
    const longestWord = findLongestWord(words);
    document.getElementById("longestWordResult").textContent = `The longest word is: ${longestWord}`;
}
